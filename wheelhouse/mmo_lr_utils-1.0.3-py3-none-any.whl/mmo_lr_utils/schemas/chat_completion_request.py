"""Chat completion related APIs.

Origin: https://github.com/stillmatic/pydantic-openai/tree/main
Reference: https://platform.openai.com/docs/api-reference/completions
"""

from enum import Enum
from typing import Annotated, Any, Dict, List, Literal, Optional, Union
from uuid import uuid4

from openai.types.chat.chat_completion import ChatCompletion
from pydantic import BaseModel, Field, ValidationInfo, field_validator
from pydantic.fields import FieldInfo


class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatMessageRole(str, Enum):
    System = "system"
    User = "user"
    Assistant = "assistant"
    Tool = "tool"


class TextContent(BaseModel):
    type: Literal["text"]
    text: str


class ImageURLContent(BaseModel):
    type: Literal["image_url"]
    image_url: dict[str, Any]


class FunctionCall(BaseModel):
    name: str
    arguments: str  # 반드시 JSON string!


class ToolCall(BaseModel):
    id: str
    type: Literal["function"]
    function: FunctionCall


class ChatCompletionMessage(BaseModel):
    role: ChatMessageRole
    content: Optional[Union[str, List[Union[TextContent, ImageURLContent]]]] = Field(
        default=None
    )
    name: Optional[str] = None
    # Assistant가 도구를 호출할 때 사용되는 도구 호출 목록
    tool_calls: Optional[List[ToolCall]] = None
    # Assistant가 호출한 도구의 응답을 매핑하기 위한 ID (role이 'tool'일 때 사용)
    tool_call_id: Optional[str] = None  # role=tool일 때 매핑 ID

    @field_validator("content", mode="before")
    @classmethod
    def normalize_content(cls, v: Any, info: ValidationInfo) -> Any:
        # Assistant가 도구를 호출하거나 Tool 응답일 때 content를 빈 문자열로 설정
        role = info.data.get("role")
        tool_calls = info.data.get("tool_calls")
        if v is None:
            if role == "assistant" and tool_calls:
                return ""
            if role == "tool":
                return ""
        return v


class ChatCompletionRequestMeta(BaseModel):
    trace_id: str = Field(default_factory=lambda: str(uuid4()))


class ChatCompletionRequest(BaseModel):
    model: str
    messages: List[ChatCompletionMessage] = Field(..., min_length=1)  # type: ignore
    max_tokens: Optional[int] = Field(None, alias="max_tokens")
    temperature: Optional[float] = Field(None, alias="temperature")
    top_p: Optional[float] = Field(None, alias="top_p")
    n: Optional[int] = Field(None, alias="n")
    stream: Optional[bool] = Field(None, alias="stream")
    stop: Optional[List[str]] = Field(None, alias="stop")
    presence_penalty: Optional[float] = Field(None, alias="presence_penalty")
    frequency_penalty: Optional[float] = Field(None, alias="frequency_penalty")
    logit_bias: Optional[Dict[str, int]] = Field(None, alias="logit_bias")
    user: Optional[str] = Field(None, alias="user")
    tools: Optional[list[Any]] = Field(None)
    tool_choice: Optional[Any] = Field(None)
    extra_headers: Optional[dict[str, str]] = Field(None)
    # extra_body: Optional[dict[str, Any]] = Field(None)

    # TODO: extra_query
    # extra_query


class ChatCompletionResponse(ChatCompletion):
    usage: Optional[Any] = None  # Should match CompletionUsage | None
    extra_info: Dict[str, Any] = Field(default_factory=dict)
