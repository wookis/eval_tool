from enum import Enum
from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any
from datetime import datetime, timezone


class SourceType(Enum):
    DATASET = "DATASET"
    KORA = "KORA"


class BronzeDataStatus(Enum):
    RAW = "RAW"
    PARSED = "PARSED"
    PARSING_ERROR = "PARSING_ERROR"


class LRDatasetsBronze(BaseModel):
    id: str
    request_id: Optional[str] = Field(None)  # UUID or hash
    source_type: Optional[SourceType] = Field(None)  # data source type
    source_id: Optional[str] = Field(None)  # 예: 001-nia-reliability-benchmark

    request_url: Optional[str] = Field(None)  # 요청 엔드포인트 URL
    request_body: Optional[str] = Field(
        None
    )  # 전체 request json (messages, params 등 포함)

    response_body: Optional[str] = Field(None)  # 전체 response json (OpenAI 응답 원문)
    model: Optional[str] = Field(None)  # 요청 모델명 (GPT-4, GPT-3.5 등)
    status_code: Optional[int] = Field(None)  # HTTP status (200, 429, 500 등)

    error_message: Optional[str] = Field(None)  # 에러 메시지 (있을 경우)

    request_created_at: Optional[datetime] = Field(None)  # 실제 요청이 생성된 시점
    response_received_at: Optional[datetime] = Field(None)  # 응답 수신 시점

    metadata: Optional[str] = Field(None)  # 파싱된 메타데이터

    collected_at: datetime = Field(None)  # 이 데이터를 bronze에 저장한 시간
    created_at: datetime = Field(None)  # delta ingestion 시각
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )  # 업데이트 시각

    data_status: Optional[str] = Field(
        None
    )  # 현재 상태 (enum: RAW, PARSED), ENUM을 직접 쓰면 Databrick에서 런타임 에러 발생함


class SilverDataStatus(Enum):
    PARSED = "PARSED"
    PARSING_ERROR = "PARSING_ERROR"
    CLEANSED = "CLEANSED"
    CLEANSING_ERROR = "CLEANSING_ERROR"
    LABELED = "LABELED"
    LABELING_ERROR = "LABELING_ERROR"
    COMPLETED = "COMPLETED"
    COMPLETION_ERROR = "COMPLETION_ERROR"


from .chat_completion_request import ChatCompletionMessage


class LRDatasetsSilver(BaseModel):
    id: str
    request_id: Optional[str] = Field(None)  # UUID or hash
    source_type: Optional[SourceType] = Field(None)  # data source type
    source_id: Optional[str] = Field(None)  # 예: 001-nia-reliability-benchmark

    messages: List[ChatCompletionMessage]
    tools: Optional[list[Any]] = Field(None)
    tool_choice: Optional[Any] = Field(None)

    capability_num_turns: Optional[int] = Field(None)
    capability_num_characters: Optional[int] = Field(None)
    capability_tool: Optional[bool] = Field(None)
    capability_multimodal: Optional[bool] = Field(None)

    labeler_llm_id: Optional[str] = Field(None)
    labeler_prompt_id: Optional[str] = Field(None)
    label_results: Optional[List[Dict[str, Any]]] = Field(None)
    label_task: Optional[List[str]] = Field(None)
    label_level: Optional[List[str]] = Field(None)
    label_domain: Optional[List[str]] = Field(None)
    label_capability: Optional[List[str]] = Field(None)
    labeler_total_elapsed_time: Optional[float] = Field(None)

    error_flag: Optional[bool] = Field(None)
    # error_type: Optional[str] = Field(None)
    # error_stacktrace: Optional[str] = Field(None)
    error_messages: Optional[List[str]] = Field(None)

    metadata: Optional[str] = Field(None)

    created_at: datetime = Field(None)
    parsed_at: Optional[datetime] = Field(None)
    deduplicated_at: Optional[datetime] = Field(None)
    labeled_at: Optional[datetime] = Field(None)
    completed_at: Optional[datetime] = Field(None)
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    data_status: str


if __name__ == "__main__":
    print(SilverDataStatus.PARSED.value)
    print(SilverDataStatus.CLEANSED.value)
    print(SilverDataStatus.LABELED.value)
    print(SilverDataStatus.COMPLETED.value)
