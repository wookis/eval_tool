import re
from pydantic import BaseModel, field_validator


# ✅ Single item field_validator
class TLDCLabelCode(BaseModel):
    value: str

    @field_validator("value")
    def validate_code(cls, v):
        if re.fullmatch(r"[TLDC]\d+", v):
            return v
        raise ValueError(f"Invalid code format: {v}")
