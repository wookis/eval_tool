import re
from pydantic import ValidationError
from typing import List
from ..schemas.label import TLDCLabelCode


# ✅ Custom Error
class InvalidTLDCCodeError(Exception):
    def __init__(self, value):
        super().__init__(
            f"Invalid value: {value}. Must be T|L|D|C' followed by digits, or a list of such strings."
        )


def extract_code_items(s: str) -> List[str]:
    # Step 1: Extract potential matches
    items = re.findall(r"[A-Za-z]\d+", s)  # 모든 문자+숫자 조합 추출

    # Step 2: Validate each item to ensure it matches the allowed pattern
    valid_items = []
    for token in items:
        if re.fullmatch(r"[TLDC]\d+", token):  # T, L, D, C로 시작하는 패턴만 허용
            valid_items.append(token)
        else:
            raise InvalidTLDCCodeError(f"Invalid token: {token}")
    return valid_items


# ✅ Main parser function
def parse_str_to_get_tldc_label(input_data: str) -> List[str]:
    # Step 1: Clean wrapping brackets if exist
    s = input_data.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1].strip()
    # Step 2: Try to extract all valid code patterns
    try:
        items = extract_code_items(s)
    except InvalidTLDCCodeError as e:
        raise InvalidTLDCCodeError(input_data)

    if not items:
        raise InvalidTLDCCodeError(input_data)
    # Step 3: Validate all items — raise if any invalid
    try:
        return [TLDCLabelCode(value=item).value for item in items]
    except ValidationError as e:
        raise InvalidTLDCCodeError(input_data)


# ✅ Function to check if a string is a valid TLDC code
def is_string_valid_tldc_code(input_data: str) -> bool:
    """
    Check if the string is a valid TLDC code.
    A valid TLDC code starts with T, L, D, or C followed by digits.
    """
    try:
        parse_str_to_get_tldc_label(input_data)
        return True
    except InvalidTLDCCodeError:
        return False
    except Exception as e:
        print(f"Unexpected error: {e}")
        return False


# test function
def tests_tldc_label():
    test_cases = [
        ("D11", ["D11"]),
        ("D1D2T12", ["D1", "D2", "T12"]),
        ("D1C2T12", ["D1", "C2", "T12"]),
        ("D1 T2 L3", ["D1", "T2", "L3"]),
        ("[D1 T12]", ["D1", "T12"]),
        ("[D11D2T3]", ["D11", "D2", "T3"]),
        ("['D1', 'T12']", ["D1", "T12"]),  # 기존 형식
        ('["D1", "T12"]', ["D1", "T12"]),  # 기존 형식
        ("X1", InvalidTLDCCodeError),
        ("[X1 T2]", InvalidTLDCCodeError),
        ("[  ]", InvalidTLDCCodeError),
        ("", InvalidTLDCCodeError),
    ]

    for i, (test_input, expected_output) in enumerate(test_cases, 1):
        print(f"\n[Test Case {i}] Input: {test_input!r}")
        try:
            result = parse_str_to_get_tldc_label(test_input)
            if isinstance(expected_output, type) and issubclass(
                expected_output, Exception
            ):
                print(
                    f"❌ FAIL: Expected exception {expected_output.__name__}, but got result: {result}"
                )
            elif result == expected_output:
                print(f"✅ PASS (result {result})")
            else:
                print(f"❌ FAIL: Expected {expected_output}, but got {result}")
        except Exception as e:
            if isinstance(expected_output, type) and isinstance(e, expected_output):
                print(f"✅ PASS (caught {e.__class__.__name__})")
            else:
                print(f"❌ FAIL: Unexpected exception {e.__class__.__name__}: {e}")


# 실행
if __name__ == "__main__":
    tests_tldc_label()
