from ..schemas.chat_completion_request import (
    ChatCompletionMessage,
    ChatMessageRole,
    TextContent,
    ImageURLContent,
)
from typing import List
import json


class InvalidMessagesError(Exception):
    def __init__(self, value):
        super().__init__(
            f"Invalid messages: {value}. Must be a list of ChatCompletionMessage or dict for ChatCompletionMessage."
        )


class InvalidSerializedDataError(Exception):
    def __init__(self, value):
        super().__init__(
            f"Invalid serialized data: {value}. Must be a valid JSON string representing a list of messages."
        )


def serialize_messages(
    messages: List[ChatCompletionMessage] | List[dict],
    must_be_start_with_system_role: bool = True,
) -> str:

    # None 값 체크
    if messages is None:
        raise InvalidMessagesError("Messages cannot be None")

    # 빈 리스트 체크
    if not messages:
        raise InvalidMessagesError("Messages list cannot be empty")

    if not isinstance(messages, list):
        raise InvalidMessagesError(
            f"Messages must be a list of ChatCompletionMessage or dict for ChatCompletionMessage. Got {type(messages)}"
        )

    list_chat_completion_message = []

    # 첫 번째 메시지의 타입을 확인하여 처리 방식 결정
    if isinstance(messages[0], dict):
        try:
            if must_be_start_with_system_role:
                if messages[0]["role"] != ChatMessageRole.System:
                    list_chat_completion_message.append(
                        ChatCompletionMessage(role=ChatMessageRole.System, content="")
                    )

            for dict_message in messages:
                # 필수 필드 검증
                if "role" not in dict_message:
                    raise InvalidMessagesError(
                        f"Missing 'role' field in message: {dict_message}"
                    )
                if "content" not in dict_message:
                    raise InvalidMessagesError(
                        f"Missing 'content' field in message: {dict_message}"
                    )

                # role 값 검증
                try:
                    role = ChatMessageRole(dict_message["role"])
                except ValueError:
                    raise InvalidMessagesError(
                        f"Invalid role value: {dict_message['role']}"
                    )

                # content 처리
                if isinstance(dict_message["content"], list):
                    list_content = []
                    for dict_content_in_list in dict_message["content"]:
                        # type 필드 검증
                        if "type" not in dict_content_in_list:
                            raise InvalidMessagesError(
                                f"Missing 'type' field in content: {dict_content_in_list}"
                            )

                        if dict_content_in_list["type"] == "text":
                            if "text" not in dict_content_in_list:
                                raise InvalidMessagesError(
                                    f"Missing 'text' field in text content: {dict_content_in_list}"
                                )
                            content_in_list = TextContent(**dict_content_in_list)
                        elif dict_content_in_list["type"] == "image_url":
                            if "image_url" not in dict_content_in_list:
                                raise InvalidMessagesError(
                                    f"Missing 'image_url' field in image_url content: {dict_content_in_list}"
                                )
                            # image_url 내부의 url 필드 검증
                            if "url" not in dict_content_in_list["image_url"]:
                                raise InvalidMessagesError(
                                    f"Missing 'url' field in image_url: {dict_content_in_list['image_url']}"
                                )
                            content_in_list = ImageURLContent(**dict_content_in_list)
                        else:
                            raise InvalidMessagesError(
                                f"Invalid content type: {dict_content_in_list['type']}"
                            )

                        list_content.append(content_in_list)
                    content = list_content
                else:
                    content = dict_message["content"]

                chat_completion_message = ChatCompletionMessage(
                    role=role,
                    content=content,
                )
                list_chat_completion_message.append(chat_completion_message)

        except InvalidMessagesError:
            raise
        except Exception as e:
            raise InvalidMessagesError(f"Error processing messages: {str(e)}")
    else:
        # ChatCompletionMessage 객체 리스트인 경우
        if must_be_start_with_system_role:
            if messages[0].role != ChatMessageRole.System:
                list_chat_completion_message.append(
                    ChatCompletionMessage(role=ChatMessageRole.System, content="")
                )
        list_chat_completion_message.extend(messages)

    list_dict_chat_completion_message = [
        m.model_dump(mode="json", exclude_none=True)
        for m in list_chat_completion_message
    ]
    return json.dumps(
        list_dict_chat_completion_message, ensure_ascii=False, separators=(",", ":")
    )


def deserialize_messages_to_list_dict(serialized_messages: str) -> List[dict]:
    """
    Deserialize a JSON string back to a list of dictionaries.

    Args:
        serialized_messages: JSON string representing a list of messages

    Returns:
        List of dict objects
    """
    if not isinstance(serialized_messages, str):
        raise InvalidSerializedDataError(
            f"Serialized messages must be a string, got {type(serialized_messages)}"
        )

    if not serialized_messages.strip():
        raise InvalidSerializedDataError("Serialized messages cannot be empty")

    try:
        # Parse the string using json.loads
        messages_data = json.loads(serialized_messages)

        if not isinstance(messages_data, list):
            raise InvalidSerializedDataError(
                "Serialized data must represent a list of messages"
            )

        return messages_data

    except json.JSONDecodeError as e:
        raise InvalidSerializedDataError(f"Invalid JSON format: {str(e)}")
    except Exception as e:
        raise InvalidSerializedDataError(f"Error deserializing messages: {str(e)}")


def deserialize_messages_to_list_chat_completion_message(
    serialized_messages: str,
) -> List[ChatCompletionMessage]:
    """
    Deserialize a JSON string back to a list of ChatCompletionMessage objects.

    Args:
        serialized_messages: JSON string representing a list of messages

    Returns:
        List of ChatCompletionMessage objects
    """
    if not isinstance(serialized_messages, str):
        raise InvalidSerializedDataError(
            f"Serialized messages must be a string, got {type(serialized_messages)}"
        )

    if not serialized_messages.strip():
        raise InvalidSerializedDataError("Serialized messages cannot be empty")

    try:
        # Parse the string using json.loads
        messages_data = json.loads(serialized_messages)

        if not isinstance(messages_data, list):
            raise InvalidSerializedDataError(
                "Serialized data must represent a list of messages"
            )

        chat_messages = []
        for message_dict in messages_data:
            if not isinstance(message_dict, dict):
                raise InvalidSerializedDataError(
                    f"Each message must be a dict, got {type(message_dict)}"
                )

            # Validate required fields
            if "role" not in message_dict:
                raise InvalidSerializedDataError(
                    f"Missing 'role' field in message: {message_dict}"
                )
            if "content" not in message_dict:
                raise InvalidSerializedDataError(
                    f"Missing 'content' field in message: {message_dict}"
                )

            # Validate role
            try:
                role = ChatMessageRole(message_dict["role"])
            except ValueError:
                raise InvalidSerializedDataError(
                    f"Invalid role value: {message_dict['role']}"
                )

            # Process content
            content = message_dict["content"]
            if isinstance(content, list):
                list_content = []
                for content_item in content:
                    if not isinstance(content_item, dict):
                        raise InvalidSerializedDataError(
                            f"Content item must be a dict, got {type(content_item)}"
                        )

                    if "type" not in content_item:
                        raise InvalidSerializedDataError(
                            f"Missing 'type' field in content: {content_item}"
                        )

                    if content_item["type"] == "text":
                        if "text" not in content_item:
                            raise InvalidSerializedDataError(
                                f"Missing 'text' field in text content: {content_item}"
                            )
                        list_content.append(TextContent(**content_item))
                    elif content_item["type"] == "image_url":
                        if "image_url" not in content_item:
                            raise InvalidSerializedDataError(
                                f"Missing 'image_url' field in image_url content: {content_item}"
                            )
                        if "url" not in content_item["image_url"]:
                            raise InvalidSerializedDataError(
                                f"Missing 'url' field in image_url: {content_item['image_url']}"
                            )
                        list_content.append(ImageURLContent(**content_item))
                    else:
                        raise InvalidSerializedDataError(
                            f"Invalid content type: {content_item['type']}"
                        )

                content = list_content

            # Create ChatCompletionMessage
            chat_message = ChatCompletionMessage(
                role=role,
                content=content,
                name=message_dict.get("name"),
                tool_calls=message_dict.get("tool_calls"),
                tool_call_id=message_dict.get("tool_call_id"),
            )
            chat_messages.append(chat_message)

        return chat_messages

    except json.JSONDecodeError as e:
        raise InvalidSerializedDataError(f"Invalid JSON format: {str(e)}")
    except Exception as e:
        raise InvalidSerializedDataError(f"Error deserializing messages: {str(e)}")


if __name__ == "__main__":
    print("=== Serialize Tests ===")

    # Test 1: Simple user message
    messages1 = [
        {
            "role": "user",
            "content": "법의학에 대해 알려줘. 법의학은 법학과 의학을 합쳐야해",
        }
    ]
    serialized1 = serialize_messages(messages1)
    print(f"Test 1 - Serialized: {serialized1}")

    # Test 2: Multiple text content
    messages2 = [
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "법의학에 대해 알려줘. 법의학은 법학과 의학을 합쳐야해",
                },
                {
                    "type": "text",
                    "text": "주로 법적 문제 해결에 의료 지식을 활용합니다.",
                },
            ],
        }
    ]
    serialized2 = serialize_messages(messages2)
    print(f"Test 2 - Serialized: {serialized2}")

    # Test 3: Text and image content
    messages3 = [
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "법의학에 대해 알려줘. 법의학은 법학과 의학을 합쳐야해",
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "https://helloworld.ai",
                    },
                },
            ],
        }
    ]
    serialized3 = serialize_messages(messages3)
    print(f"Test 3 - Serialized: {serialized3}")

    # Test 4: ChatCompletionMessage objects
    messages4 = [
        ChatCompletionMessage(
            role=ChatMessageRole.User,
            content="법의학에 대해 알려줘. 법의학은 법학과 의학을 합쳐야해",
        )
    ]
    serialized4 = serialize_messages(messages4)
    print(f"Test 4 - Serialized: {serialized4}")

    # Test 5: System and user messages
    messages5 = [
        {
            "role": "system",
            "content": "당신은 법의학 전문가입니다.",
        },
        {
            "role": "user",
            "content": "법의학에 대해 설명해주세요.",
        },
    ]
    serialized5 = serialize_messages(messages5)
    print(f"Test 5 - Serialized: {serialized5}")

    print("\n=== Deserialize Tests ===")

    # Test 6: Deserialize to dict
    print("Test 6 - Deserialize to dict:")
    serialized1 = serialize_messages(messages1, must_be_start_with_system_role=False)
    deserialized1_dict = deserialize_messages_to_list_dict(serialized1)
    print(f"  Original: {messages1}")
    print(f"  Deserialized: {deserialized1_dict}")
    print(f"  Match: {messages1 == deserialized1_dict}")

    # Test 7: Deserialize to ChatCompletionMessage
    print("\nTest 7 - Deserialize to ChatCompletionMessage:")
    deserialized1_obj = deserialize_messages_to_list_chat_completion_message(
        serialized1
    )
    print(f"  Original: {messages1}")
    print(f"  Deserialized: {[msg.model_dump() for msg in deserialized1_obj]}")

    # Test 8: Deserialize complex content
    print("\nTest 8 - Deserialize complex content to dict:")
    serialized3 = serialize_messages(messages3, must_be_start_with_system_role=False)
    deserialized3_dict = deserialize_messages_to_list_dict(serialized3)
    print(f"  Original: {messages3}")
    print(f"  Deserialized: {deserialized3_dict}")
    print(f"  Match: {messages3 == deserialized3_dict}")

    # Test 9: Deserialize complex content to objects
    print("\nTest 9 - Deserialize complex content to ChatCompletionMessage:")
    deserialized3_obj = deserialize_messages_to_list_chat_completion_message(
        serialized3
    )
    print(f"  Original: {messages3}")
    print(f"  Deserialized: {[msg.model_dump() for msg in deserialized3_obj]}")

    # Test 10: Round trip test
    print("\nTest 10 - Round trip test:")
    original_messages = [
        {
            "role": "system",
            "content": "당신은 법의학 전문가입니다.",
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "법의학에 대해 설명해주세요.",
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "https://example.com/image.jpg",
                    },
                },
            ],
        },
    ]

    # Serialize
    serialized_round = serialize_messages(original_messages)
    print(f"  Serialized: {serialized_round}")

    # Deserialize to dict
    deserialized_round_dict = deserialize_messages_to_list_dict(serialized_round)
    print(f"  Deserialized to dict: {deserialized_round_dict}")
    print(f"  Round trip match (dict): {original_messages == deserialized_round_dict}")

    # Deserialize to objects
    deserialized_round_obj = deserialize_messages_to_list_chat_completion_message(
        serialized_round
    )
    print(
        f"  Deserialized to objects: {[msg.model_dump() for msg in deserialized_round_obj]}"
    )

    print("\n=== Error Handling Tests ===")

    # Test 11: Invalid JSON
    try:
        deserialize_messages_to_list_dict("invalid json")
    except InvalidSerializedDataError as e:
        print(f"Test 11 - Invalid JSON error: {e}")

    # Test 12: Empty string
    try:
        deserialize_messages_to_list_dict("")
    except InvalidSerializedDataError as e:
        print(f"Test 12 - Empty string error: {e}")

    # Test 13: Invalid content type
    try:
        invalid_json = (
            '[{"role": "user", "content": [{"type": "invalid_type", "text": "test"}]}]'
        )
        deserialize_messages_to_list_dict(invalid_json)
    except InvalidSerializedDataError as e:
        print(f"Test 13 - Invalid content type error: {e}")

    print("\nAll tests completed!")
