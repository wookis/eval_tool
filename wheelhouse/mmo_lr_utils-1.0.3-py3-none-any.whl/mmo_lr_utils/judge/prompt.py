#!/usr/bin/env python3
import json
from pathlib import Path
from typing import Optional
from ..logger import logger


class SystemPromptForJudge:
    path_prompt_root_dir = Path(__file__).parent / "prompt"

    def __init__(
        self,
        version: str = "v1.01",
    ):
        logger.info(f"Loading prompts for LLM as a judge for version: {version}")
        path_prompt = (
            SystemPromptForJudge.path_prompt_root_dir
            / version
            / f"prompt-llm-as-a-judge-{version}.txt"
        )
        assert path_prompt.exists(), f"Prompt file not found: {path_prompt}"
        with open(path_prompt, "r", encoding="utf-8") as f:
            self.prompt = json.dumps(f.read(), ensure_ascii=False).strip()

    def get_prompt(self) -> str:
        return self.prompt


if __name__ == "__main__":
    llm_as_a_judge_prompt = SystemPromptForJudge()
    print(f"LLM as a judge Prompt:\n{llm_as_a_judge_prompt.get_prompt()}\n")
