from .prompt import SystemPromptForJudge
